<?php

// if(function_exists("register_field_group"))
// {
// 	register_field_group(array (
// 		'id' => 'acf_evento_data_hora',
// 		'title' => 'Dados evento',
// 		'fields' => array (
// 			array (
// 				'key' => 'field_evento_data_hora',
// 				'label' => 'Data e hora do evento',
// 				'name' => 'evento_data_hora',
// 				'type' => 'date_time_picker',
// 				'required' => 1,
// 				'show_date' => 'true',
// 				'date_format' => 'm/d/y',
// 				'time_format' => 'h:mm tt',
// 				'show_week_number' => 'false',
// 				'picker' => 'select',
// 				'save_as_timestamp' => 'true',
// 				'get_as_timestamp' => 'true',
// 			),
// 		),
// 		'location' => array (
// 			array (
// 				array (
// 					'param' => 'post_type',
// 					'operator' => '==',
// 					'value' => 'eventos',
// 					'order_no' => 0,
// 					'group_no' => 0,
// 				),
// 			),
// 		),
// 		'options' => array (
// 			'position' => 'normal',
// 			'layout' => 'default',
// 			'hide_on_screen' => array (
// 			),
// 		),
// 		'menu_order' => 1,
// 	));
// }



?>